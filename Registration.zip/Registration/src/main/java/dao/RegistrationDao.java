package dao;

import model.Registration;

public interface RegistrationDao {
	public void createCustomer(Registration registration);

}
