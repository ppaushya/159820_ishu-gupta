package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import model.Registration;

public class RegistrationDaoImpl implements RegistrationDao {

	@Override
	public void createCustomer(Registration registration) {
		String sql="insert into employee(CustomerName,mobileNo,RegistrationFees,age,actualregistrationFees values(?,?,?,?,?)";
		
		try(Connection conn=getDbConnection()) {
			//	Statement statement=conn.createStatement();
				
				PreparedStatement statement=conn.prepareStatement(sql);
//				statement.setInt(1, registration.getRegistrationId());
				statement.setString(1, registration.getCustomerName());
				statement.setString(2, registration.getMobileNo());
				statement.setDouble(3, registration.getRegistrationFee());
				statement.setInt(4,registration.getAge());
				statement.setDouble(5, registration.getActualFeesPaid());
				
				
				//int count=statement.executeUpdate(sql);
				int count=statement.executeUpdate();
				
				if(count>0)
					System.out.println("Insertion done!");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
		}
		
	
	private Connection getDbConnection() {
		Connection connection=null;
		try{	
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection
					("jdbc:mysql://localhost:3306/mydb", "root", "root");
			return connection;
		}catch (ClassNotFoundException|SQLException e) {
			e.printStackTrace();
		}
		
		return null;
		
	}
	

}
