package service;

import dao.RegistrationDao;
import dao.RegistrationDaoImpl;

import model.Registration;

public class RegistrationServiceImpl implements IRegistrationService {
	RegistrationDao registrationDao=new RegistrationDaoImpl();
	
	@Override
	public void createCustomer(Registration registration) {
		if(isValidCustomer(registration)) {
			registrationDao.createCustomer(registration);
		}
	}
		
	
	private boolean isValidCustomer(Registration registration) {
		boolean flag=false;
		
		 {
			if(registration.getMobileNo().matches("(7|8|9)\\d{9}"))
				flag=true;
			else
				flag=false;
		}
		
		
		return flag;
	}

}
