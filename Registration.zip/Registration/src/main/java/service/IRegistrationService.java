package service;

import model.Registration;

public interface IRegistrationService {

	void createCustomer(Registration registration);

	
}
