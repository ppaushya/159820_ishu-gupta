package org.AAA.view;

import java.util.List;

import org.AAA.model.Customer;
import org.AAA.util.Utility;



public class UserInteraction {
	
	public static Customer getCustomerDetails() {
		Customer customer=new Customer();
		customer.setCustomerId(Utility.generateAccountNo());
		customer.setFirstName(Utility.promptFname());
		customer.setLastName(Utility.promptLname());
		customer.setEmailId(Utility.promptEmailId());
		customer.setMobileNo(Utility.promptMobileNo());
		customer.setDateOfBirth(Utility.promptDOB());
		customer.setAddress(Utility.promptAddress());
		return customer;
	}
	
	public static void printCustomers(List<Customer> customers ) {
		for(Customer customer:customers)
		System.out.println(customer);
	}
	
	

}
