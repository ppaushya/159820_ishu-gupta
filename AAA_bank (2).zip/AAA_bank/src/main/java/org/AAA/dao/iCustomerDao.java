package org.AAA.dao;

import java.util.List;

import org.AAA.model.Customer;

public interface iCustomerDao {

	public List<Customer>getCustomers();
	public void createCustomers(Customer customer);
}
