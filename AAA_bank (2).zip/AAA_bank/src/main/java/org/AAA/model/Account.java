package org.AAA.model;

import java.time.LocalDate;

public class Account {
	private String accountNo;
	private AccountType accounttype;
	private LocalDate openingDate;
	private double openingBalance;
	private String description;
	
	
	public Account() {
		
	}
	
	
	public Account(String accountNo, AccountType accounttype, LocalDate openingDate, double openingBalance,
			String description) {
		super();
		this.accountNo = accountNo;
		this.accounttype = accounttype;
		this.openingDate = openingDate;
		this.openingBalance = openingBalance;
		this.description = description;
	}


	public String getAccountNo() {
		return accountNo;
	}


	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}


	public AccountType getAccounttype() {
		return accounttype;
	}


	public void setAccounttype(AccountType accounttype) {
		this.accounttype = accounttype;
	}


	public LocalDate getOpeningDate() {
		return openingDate;
	}


	public void setOpeningDate(LocalDate openingDate) {
		this.openingDate = openingDate;
	}


	public double getOpeningBalance() {
		return openingBalance;
	}


	public void setOpeningBalance(double openingBalance) {
		this.openingBalance = openingBalance;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", accounttype=" + accounttype + ", openingDate=" + openingDate
				+ ", openingBalance=" + openingBalance + ", description=" + description + "]";
	}
	
	
	
	

}
