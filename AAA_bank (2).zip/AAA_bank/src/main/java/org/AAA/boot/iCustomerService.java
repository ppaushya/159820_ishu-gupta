package org.AAA.boot;

import java.util.List;

import org.AAA.model.Customer;

public interface iCustomerService {
	
	public List<Customer>getCustomers();
	public void createCustomers(Customer customer);

}
