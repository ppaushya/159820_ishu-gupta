package org.AAA.boot;

import java.util.Scanner;

import org.AAA.dao.CustomerDao;
import org.AAA.model.Customer;
import org.AAA.view.UserInteraction;

public class BootClass {

	public static void main(String[] args) {
		
	
		UserInteraction ui=new UserInteraction();
		CustomerServiceImpl obj2=new CustomerServiceImpl();
		
		Scanner s=new Scanner(System.in);
		System.out.println("enter choices [1,2,3,4,5]");
		System.out.println("create customer");
		System.out.println("view customer");
		System.out.println("create account");
		System.out.println("fund transfer");
		System.out.println("view transaction");
		System.out.println("exit");
		int choice=s.nextInt();
		
		switch(choice)
		{
		case 1:
			int count=obj2.getCustomers().size();
			Customer customer=ui.getCustomerDetails();
			//1System.out.println(customer);
			obj2.createCustomers(customer);
			System.out.println("Account created successfully");
			if(count==obj2.getCustomers().size())
				System.out.println("not added");
			break;
			
		case 2:
			
			ui.printCustomers(obj2.getCustomers());
			break;
		}
		
	}

}
