package org.AAA.boot;

import java.time.LocalDate;
import java.util.List;

import org.AAA.dao.CustomerDao;
import org.AAA.model.Customer;

public class CustomerServiceImpl implements iCustomerService {
	
   CustomerDao obj4=new CustomerDao();

	@Override
	public List<Customer> getCustomers() {
		
		return obj4.getCustomers();
	}

	@Override
	public void createCustomers(Customer customer) {
		if (isValid(customer)) {
			obj4.createCustomers(customer);
		}
		
	}
	
	private boolean isValid(Customer customer) {
		boolean flag=false;
		if(customer.getDateOfBirth().isBefore(LocalDate.now())) {
			if(customer.getMobileNo().matches("(7|8|9)\\d{9}"))
				flag=true;
			else
				flag=false;
		}else
			flag=false;
		return flag;
	}
		
	

}
