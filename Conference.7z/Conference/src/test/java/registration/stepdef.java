package registration;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepdef {
	
	private WebDriver webdriver;
	private WebElement element;
	
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\igupta\\Downloads\\chromedriver.exe" );
		webdriver=new ChromeDriver();
	}
	
	@Given("^Open Registration Page$")
	public void valid_Registration_Details() throws Throwable {
	    webdriver.get("file:///C:/Users/igupta/Downloads/Conferencebooking/ConferenceRegistartion.html#");
	    
	}

	@When("^Title of the page is 'Conference Registration'$")
	public void title_of_the_page_is_Conference_Registration() throws Throwable {
		String title=webdriver.getTitle();
	    assertEquals("Conference Registartion", title);
	}

	@When("^Heading of the page is 'Step 1: Personal Details'$")
	public void heading_of_the_page_is_Personal_Details() throws Throwable {
	   webdriver.findElement(By.tagName("h4")).equals("Step 1: Personal Details");
	   
	}
	
	@When("^All the fields are present on the webpage$")
	public void all_the_fields_are_present_on_the_webpage() throws Throwable {
	 if( webdriver.findElement(By.xpath("//*[@id=\"txtFirstName\"]"))!=null)
		 System.out.println("TRUE");
	 else
		 System.out.println("FALSE");
	 if(webdriver.findElement(By.xpath("//*[@id=\"txtLastName\"]"))!=null)
		 System.out.println("TRUE");
		 else
		 System.out.println("FALSE");
		 if(webdriver.findElement(By.xpath("//*[@id=\"txtEmail\"]"))!=null)
		 System.out.println("TRUE");
		 else
		 System.out.println("FALSE");
		 if(webdriver.findElement(By.xpath("//*[@id=\"txtPhone\"]"))!=null)
		 System.out.println("TRUE");
		 else
		 System.out.println("FALSE");
		 if(webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[5]/td[2]/select"))!=null)
		 System.out.println("TRUE");
		 else
		 System.out.println("FALSE");
		 if(webdriver.findElement(By.xpath("//*[@id=\"txtAddress1\"]"))!=null)
		 System.out.println("TRUE");
		 else
		 System.out.println("FALSE");
		 if(webdriver.findElement(By.xpath("//*[@id=\"txtAddress2\"]"))!=null)
		 System.out.println("TRUE");
		 else
		 System.out.println("FALSE");
		 if(webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[10]/td[2]/select"))!=null)
		 System.out.println("TRUE");
		 else
		 System.out.println("FALSE");
		 if(webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[9]/td[2]/select"))!=null)
		 System.out.println("TRUE");
		 else
		 System.out.println("FALSE");
		 if(webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[12]/td[2]/input"))!=null)
		 System.out.println("TRUE");
		 else
		 System.out.println("FALSE");
	 
	}
	
	@When("^All the fields are filled$")
	public void all_the_fields_are_filled() throws Throwable {
	   if(webdriver.findElement(By.xpath("//*[@id=\\\"txtFirstName\"]")).getText()==null) {
		   webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a")).click();
		   Alert alert=webdriver.switchTo().alert();
		   assertEquals(alert.getText(), "Enter First Name");
		   
	   }
	}
	
	

	@Then("^Show alert box with the message 'registration successful'$")
	public void show_alert_box_with_the_message_registration_successful() throws Throwable {
	   
		webdriver.findElement(By.name("txtFN")).sendKeys("Mehul");
		webdriver.findElement(By.name("txtLN")).sendKeys("Sharma");
		webdriver.findElement(By.name("Email")).sendKeys("mehul@gmail.com");
		webdriver.findElement(By.name("Phone")).sendKeys("7324578103");
		Select dropdown = new Select(webdriver.findElement(By.name("size")));
		dropdown.selectByVisibleText("3");
		webdriver.findElement(By.name("Address")).sendKeys("avigna");
		webdriver.findElement(By.name("Address2")).sendKeys("noida");
		Select dropdown1 = new Select(webdriver.findElement(By.name("city")));
		dropdown1.selectByVisibleText("Hyderabad");

		Select dropdown2 = new Select(webdriver.findElement(By.name("state")));
		dropdown2.selectByVisibleText("Telangana");
		WebElement radio1 = webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[12]/td[2]/input"));
		        //Radio Button1 is selected
		        radio1.click();
		        
		     WebElement radio2 = webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[13]/td[2]/input"));
		       
		        radio2.click();
		        
		      
		        WebElement click = webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a")); 
		       
		              
		                click.click(); 
		                

		                Alert alert = webdriver.switchTo().alert();
		              
		             alert.accept();
		                
		          webdriver.navigate().to("file:///C:/Users/igupta/Downloads/Conferencebooking/PaymentDetails.html"); 

		
	}


}
