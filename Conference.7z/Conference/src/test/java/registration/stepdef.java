package registration;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepdef {
	
	private WebDriver webDriver;
	private WebElement webElement;

	@Before
	public void setUp() {
	System.setProperty("webdriver.chrome.driver","C:\\Users\\igupta\\Downloads\\chromedriver.exe");
	webDriver=new ChromeDriver();
	}

	@Given("^Open Registration Page$")
	public void open_Registration_Page() throws Throwable {
	webDriver.get("file:///C:/Users/igupta/Downloads/Conferencebooking/ConferenceRegistartion.html");

	}

	@When("^Title of the page is 'Conference Registration'$")
	public void title_of_the_page_is_Conference_Registration() throws Throwable {
	String title=webDriver.getTitle();
	assertEquals("Conference Registartion", title);
	}

	@When("^Heading of the page is 'Step (\\d+): Personal Details'$")
	public void heading_of_the_page_is_Step_Personal_Details(int arg1) throws Throwable {
	webDriver.findElement(By.tagName("h4")).equals("Step 1: Personal Details");

	}

	@When("^All the fields are present in the page$")
	public void all_the_fields_are_present_in_the_page() throws Throwable {
	if(webDriver.findElement(By.xpath("//*[@id=\"txtFirstName\"]"))!=null)
	System.out.println("TRUE");
	else
	System.out.println("FALSE");
	if(webDriver.findElement(By.xpath("//*[@id=\"txtLastName\"]"))!=null)
	System.out.println("TRUE");
	else
	System.out.println("FALSE");
	if(webDriver.findElement(By.xpath("//*[@id=\"txtEmail\"]"))!=null)
	System.out.println("TRUE");
	else
	System.out.println("FALSE");
	if(webDriver.findElement(By.xpath("//*[@id=\"txtPhone\"]"))!=null)
	System.out.println("TRUE");
	else
	System.out.println("FALSE");
	if(webDriver.findElement(By.xpath("/html/body/form/table/tbody/tr[5]/td[2]/select"))!=null)
	System.out.println("TRUE");
	else
	System.out.println("FALSE");
	if(webDriver.findElement(By.xpath("//*[@id=\"txtAddress1\"]"))!=null)
	System.out.println("TRUE");
	else
	System.out.println("FALSE");
	if(webDriver.findElement(By.xpath("//*[@id=\"txtAddress2\"]"))!=null)
	System.out.println("TRUE");
	else
	System.out.println("FALSE");
	if(webDriver.findElement(By.xpath("/html/body/form/table/tbody/tr[10]/td[2]/select"))!=null)
	System.out.println("TRUE");
	else
	System.out.println("FALSE");
	if(webDriver.findElement(By.xpath("/html/body/form/table/tbody/tr[9]/td[2]/select"))!=null)
	System.out.println("TRUE");
	else
	System.out.println("FALSE");
	if(webDriver.findElement(By.xpath("/html/body/form/table/tbody/tr[12]/td[2]/input"))!=null)
	System.out.println("TRUE");
	else
	System.out.println("FALSE");
	}

	@When("^First Name is not filled$")
	public void first_Name_is_not_filled() throws Throwable {
	webDriver.findElement(By.xpath("//*[@id=\"txtFirstName\"]")).sendKeys("");

	}

	@Then("^Alert message is 'Please fill the First Name'$")
	public void alert_message_is_Please_fill_the_First_Name() throws Throwable {
	webDriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a")).click();
	Alert alert=webDriver.switchTo().alert();
	Thread.sleep(2000);
	assertEquals(alert.getText(), "Please fill the First Name");
	alert.accept();

	}


	@When("^Last Name is not filled$")
	public void last_Name_is_not_filled() throws Throwable {
	webDriver.findElement(By.xpath("//*[@id=\"txtFirstName\"]")).sendKeys("Mehul");
	webDriver.findElement(By.xpath("//*[@id=\"txtLastName\"]")).sendKeys("");
	}



	@Then("^Alert message is 'Please fill the Last Name'$")
	public void alert_message_is_Please_fill_the_Last_Name() throws Throwable {
	webDriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a")).click();
	Alert alert=webDriver.switchTo().alert();
	Thread.sleep(2000);
	assertEquals(alert.getText(), "Please fill the Last Name");
	alert.accept();
	}
	@When("^Email is not filled$")
	public void email_is_not_filled() throws Throwable {
	//webDriver.findElement(By.xpath("//*[@id=\"txtFirstName\"]")).sendKeys("Mehul");
	webDriver.findElement(By.xpath("//*[@id=\"txtLastName\"]")).sendKeys("sharma");
	webDriver.findElement(By.xpath("//*[@id=\"txtEmail\"]")).sendKeys("");
	}

	@Then("^Alert message is 'Please fill the Email'$")
	public void alert_message_is_Please_fill_the_Email() throws Throwable {
	webDriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a")).click();
	Alert alert=webDriver.switchTo().alert();
	Thread.sleep(2000);
	assertEquals(alert.getText(), "Please fill the Email");
	alert.accept();
	}

	@When("^Invalid Email is filled$")
	public void invalid_Email_is_filled() throws Throwable {
	webDriver.findElement(By.xpath("//*[@id=\"txtEmail\"]")).sendKeys("niha");
	}

	@Then("^Alert message is 'Please enter valid Email Id\\.'$")
	public void alert_message_is_Please_enter_valid_Email_Id() throws Throwable {
	webDriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a")).click();
	Alert alert=webDriver.switchTo().alert();
	Thread.sleep(2000);
	assertEquals(alert.getText(), "Please enter valid Email Id.");
	alert.accept();
	}

	@When("^Contact No\\. is not filled$")
	public void contact_No_is_not_filled() throws Throwable {
	webDriver.findElement(By.xpath("//*[@id=\"txtEmail\"]")).sendKeys("@gmail.com");
	webDriver.findElement(By.xpath("//*[@id=\"txtPhone\"]")).sendKeys("");

	}

	@Then("^Alert message is 'Please fill the Contact No\\.'$")
	public void alert_message_is_Please_fill_the_Contact_No() throws Throwable {
	webDriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a")).click();
	Alert alert=webDriver.switchTo().alert();
	Thread.sleep(2000);
	assertEquals(alert.getText(), "Please fill the Contact No.");
	alert.accept();
	}

	@When("^Contact No\\. is not in proper format$")
	public void contact_No_is_not_in_proper_format() throws Throwable {
	webDriver.findElement(By.xpath("//*[@id=\"txtPhone\"]")).sendKeys("78");
	}

	@Then("^Alert message is 'Please enter valid Contact No\\.'$")
	public void alert_message_is_Please_enter_valid_Contact_No() throws Throwable {
	webDriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a")).click();
	Alert alert=webDriver.switchTo().alert();
	Thread.sleep(2000);
	assertEquals(alert.getText(), "Please enter valid Contact no.");
	alert.accept();
	//webDriver.findElement(By.xpath("//*[@id=\"txtPhone\"]")).sendKeys("");
	}

	@When("^Number of persons attending is not filled$")
	public void number_of_persons_attending_is_not_filled() throws Throwable {
	webDriver.findElement(By.xpath("//*[@id=\"txtPhone\"]")).sendKeys("96541230");
	Select dropDown = new Select(webDriver.findElement(By.name("size")));

	}

	@Then("^Alert message is 'Number of people attending\\.'$")
	public void alert_message_is_Number_of_people_attending() throws Throwable {
	webDriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a")).click();
	Alert alert=webDriver.switchTo().alert();
	Thread.sleep(2000);
	assertEquals(alert.getText(), "Please fill the Number of people attending");
	alert.accept();
	}

	@When("^Valid registration details are filled$")
	public void valid_registration_details_are_filled() throws Throwable {
	Select dropDown = new Select(webDriver.findElement(By.name("size")));
	dropDown.selectByVisibleText("3");
	webDriver.findElement(By.name("Address")).sendKeys("avenue");
	webDriver.findElement(By.name("Address2")).sendKeys("Hyderabad");
	Select dropDown1 = new Select(webDriver.findElement(By.name("city")));
	dropDown1.selectByVisibleText("Hyderabad");

	     
	Select dropDown2 = new Select(webDriver.findElement(By.name("state")));
	dropDown2.selectByVisibleText("Telangana");
	WebElement radio1 = webDriver.findElement(By.xpath("/html/body/form/table/tbody/tr[12]/td[2]/input"));
	        //Radio Button1 is selected
	        radio1.click(); 
	}

	@Then("^open payment page$")
	public void open_payment_page() throws Throwable {
	webDriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a")).click();
	Alert alert=webDriver.switchTo().alert();
	Thread.sleep(1000);
	assertEquals(alert.getText(), "Personal details are validated.");
	alert.accept();
	webDriver.navigate().to("file:///C:/Users/igupta/Downloads/Conferencebooking/PaymentDetails.html");
	webDriver.quit();
	}


	}


