package org.AAA.view;

import org.AAA.model.Customer;
import org.AAA.util.Utility;



public class UserInteraction {
	
	public static Customer getCustomerDetails() {
		Customer customer=new Customer();
		customer.setCustomerId(Utility.generateAccountNo());
		customer.setFirstName(Utility.promptFname());
		customer.setLastName(Utility.promptLname());
		customer.setEmailId(Utility.promptEmailId());
		customer.setMobileNo(Utility.promptMobileNo());
		customer.setDateOfBirth(Utility.promptDOB());
		customer.setAddress(Utility.promptAddress());
		return customer;
	}
	
	
	

}
