package org.AAA.model;

public enum AccountType {

	SAVINGS,CURRENT,RD,FD;
}
