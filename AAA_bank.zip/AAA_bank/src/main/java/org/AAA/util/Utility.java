package org.AAA.util;

import java.time.LocalDate;
import java.util.Scanner;

import org.AAA.model.Address;

public class Utility {
	static Scanner s=new Scanner(System.in);
	
	public static int generateAccountNo() {
		return (int)Math.random()*1000;
	}
	
	public static String promptFname() {
		boolean flag=false;
		String fName;
		do {
			System.out.println("Enter first name");
			 fName=s.next();
			flag=fName.matches("[a-zA-Z]{3,}");
			
			if(!flag) {
				System.out.println("Enter a valid first name");
			}
		}while(!flag);
		return fName;
			
	
	}
	
	
	public static String promptLname() {
		boolean flag=false;
		String Lname;
		do {
			System.out.println("Enter last name");
			 Lname=s.next();
			flag=Lname.matches("[a-zA-Z]{3,}");
			
			if(!flag) {
				System.out.println("Enter a valid last name");
			}
		}while(!flag);
		return Lname;
		
	}
	
	public static String promptEmailId() {
	
		boolean flag=false;
		String email;
		do {
		System.out.println("Enter email address");
		email=s.next();
		flag=email.matches("[a-zA-z0-9]+[@]{1}(gmail){1}[.]{1}(com){1}" );
		
		if(!flag) {
			System.out.println("Enter a valid email id");
		}
	}while(!flag);
	return email;
		
	}
	
	public static String promptMobileNo() {
		
		boolean flag=false;
		String mobile;
		do {
		System.out.println("Enter mobile number");
		mobile=s.next();
		flag=mobile.matches("[0-9]{10}");
		
		if(!flag) {
			System.out.println("Enter a valid email id");
		}
	}while(!flag);
	return mobile;
		
	}

	public static LocalDate promptDOB()
	    {
	       String dob;
	        Integer date,month,year;
	        boolean flag=false;
	        do {
	            System.out.println("Enter Date of Birth(dd-mm-yyyy) :");
	            dob=s.next();
	            date=Integer.parseInt(dob.substring(0, 2));
	            month=Integer.parseInt(dob.substring(3, 5));
	            year=Integer.parseInt(dob.substring(6, 9));
	            if(dob.charAt(2)!='-'||dob.charAt(5)!='-')
	            {
	            	System.out.println("Enter the valid Date of Birth(dd-mm-yyyy): ");
	            	flag=false;
	            }
	            else flag=true;
	        }while(!flag);
	      
		return LocalDate.of(year, month, date);
	    }
	
	public static String promptAddressLine1() {
		boolean flag=false;
		String add1;
		do {
		System.out.println("Enter address line 1");
		add1=s.next();
		flag=add1.matches("[0-9a-zA-Z]{5,}");
		
		if(!flag) {
			System.out.println("Enter a valid address line 1");
		}
	}while(!flag);
	return add1;
		
	}
		
	public static String promptAddressLine2() {
		boolean flag=false;
		String add2;
		do {
		System.out.println("Enter address line 2");
		add2=s.next();
		flag=add2.matches("[0-9a-zA-Z]{5,}");
		
		if(!flag) {
			System.out.println("Enter a valid address line 2");
		}
	}while(!flag);
	return add2;
		
	}
	
	public static String promptCity() {
		boolean flag=false;
		String city;
		do {
		System.out.println("Enter city");
		city=s.next();
		flag=city.matches("[a-zA-Z]");
		
		if(!flag) {
			System.out.println("Enter a valid city");
		}
	}while(!flag);
	return city;
		
	}
	
	public static String promptState() {
		boolean flag=false;
		String state;
		do {
		System.out.println("Enter state");
		state=s.next();
		flag=state.matches("[a-zA-Z]");
		
		if(!flag) {
			System.out.println("Enter a valid state");
		}
	}while(!flag);
	return state;
		
	}
	
	public static String promptPincode() {
		boolean flag=false;
		String pincode;
		do {
		System.out.println("Enter pincode");
		pincode=s.next();
		flag=pincode.matches("[0-9]{6}");
		
		if(!flag) {
			System.out.println("Enter a valid pincode");
		}
	}while(!flag);
	return pincode;
		
	}
	
	public static Address promptAddress() {
		Address address=new Address();
		address.setAddress1(promptAddressLine1());
		address.setAddress2(promptAddressLine2());
		address.setCity(promptCity());
		address.setState(promptState());
		address.setPincode(promptPincode());
		return address;
		
		
	}
	        

	

	
	
	
}
