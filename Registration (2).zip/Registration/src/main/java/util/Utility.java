package util;

public class Utility {

	public static boolean isValidName(String name) {
		return name.matches("[a-zA-Z]{3,}");
	}
	
	public static boolean isValidMobile(String mobile) {
		return mobile.matches("\\d{10}");
	}
}
