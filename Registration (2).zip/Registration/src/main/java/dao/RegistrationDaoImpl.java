package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import model.Registration;

public class RegistrationDaoImpl implements RegistrationDao {

	// entering data into tables
	
	@Override
	public void createCustomer(Registration registration) {
		String sql="insert into Registration values(null,?,?,?,?,?)";
		
		
		try(Connection conn=getDbConnection()) {
			//	Statement statement=conn.createStatement();
				
				PreparedStatement statement=conn.prepareStatement(sql);
//				statement.setInt(1, registration.getRegistrationId());
				statement.setString(1, registration.getCustomerName());
				statement.setString(2, registration.getMobileNo());
				statement.setDouble(3, registration.getRegistrationFee());
				statement.setInt(4,registration.getAge());
				statement.setDouble(5, registration.getActualFeesPaid());
				
				int count=statement.executeUpdate();
				
				// registration slip
				
				if(count>0)
					System.out.println("Insertion done!");
				String select="Select max(RegistrationId) from registration";
                PreparedStatement pst1=conn.prepareStatement(select);
                ResultSet res=pst1.executeQuery();
                while(res.next())
				{System.out.println("Congratulations!! You have successfully registered"
						+"\nYour Registration ID is " + res.getInt(1));} 
//                int j=res.getInt(1);
//                String select1="Select actualFeesPaid from registration where RegistrationId=j";
//                PreparedStatement pst2=conn.prepareStatement(select1);
//                ResultSet res1=pst2.executeQuery();
//                while(res1.next())
//				{System.out.println("Congratulations!! You have successfully registered"
//						+"\nYour fees paid is " + res.getDouble(6));} 
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
		}
		
	
	private Connection getDbConnection() {
		Connection connection=null;
		try{	
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection
					("jdbc:mysql://localhost:3306/mydb", "root", "India123");
			return connection;
		}catch (ClassNotFoundException|SQLException e) {
			e.printStackTrace();
		}
		
		return null;
		
	}


}
