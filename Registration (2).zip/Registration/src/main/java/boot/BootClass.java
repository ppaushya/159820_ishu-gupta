package boot;

import java.util.Scanner;

import dao.RegistrationDaoImpl;
import model.Registration;
import service.IRegistrationService;
import service.RegistrationServiceImpl;
import view.UserInteraction;

public class BootClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	Scanner s=new Scanner(System.in);
		int choice;
UserInteraction ui=new UserInteraction();
IRegistrationService regService=new RegistrationServiceImpl();
RegistrationDaoImpl regDao=new RegistrationDaoImpl();
System.out.println("Enter choice");
System.out.println("1.Customer Registration");
System.out.println("2.exit");
choice=s.nextInt();

int option;
do{
	
	
switch(choice)

{
case 1:
	
	Registration reg=ui.addRegDetails();
	regService.createCustomer(reg);
	break;
case 2:
	System.out.println("thanks for registration");
	System.exit(0);
	break;
	
	
	
}	

System.out.println("Do u want to continue.if yes press 1");
option=s.nextInt();

}while(option==1);
	}}




