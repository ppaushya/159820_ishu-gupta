package view;

import java.util.Scanner;

import model.Registration;
import util.Utility;

public class UserInteraction {
	 Scanner s=new Scanner(System.in);
	public Registration addRegDetails() {
		Registration registration=new Registration();
		
		registration.setCustomerName(promptName());
		registration.setMobileNo(promptMobile());
		System.out.println("enter age");
		int age=s.nextInt();
		registration.setAge(age);
		System.out.println("enter registration fees");
		double fees=s.nextDouble();
		registration.setRegistrationFee(fees);
		double actualFees=actualFees(age,fees);
	    registration.setActualFeesPaid(actualFees);
//	    System.out.println(registration);
		
		return registration;
	}	
		
		public String promptName() {
			boolean flag=false;
			String name;
			do {
				System.out.println("Enter Name:");
				name=s.next();
				flag=Utility.isValidName(name);
				if(!flag)
					System.out.println("Please enter Valid Name!");
			}while(!flag);
			
			return name;
		}
		
		public String promptMobile() {
			boolean flag=false;
			String mobile;
			do {
				System.out.println("Enter mobile Number:");
				mobile=s.next();
				flag=Utility.isValidMobile(mobile);
				if(!flag)
					System.out.println("Please enter Valid 10 digit Mobile!");
			}while(!flag);
			
			return mobile;
		}
		
		public double actualFees(int age,double fees) {
			double actualFees;
			if(age>0 && age<=18)
				 actualFees=fees;
			else if(age>18 & age<=25)
				actualFees=0.1*fees+fees;
			else if(age>25 & age<=50)
				actualFees=0.2*fees+fees;
			else
				actualFees=0.3*fees+fees;
			return actualFees;
			
		}
		
	

}
